package com.zybooks.mainproject;

// Handles the events on a individual item page
public class InventoryItemActivity {
}
